// Nav.js
import React from 'react';
import './Nav.css';
import { BiSearch } from 'react-icons/bi';
import { Link } from 'react-router-dom';

const Nav = () => {
  return (
    <div>
      <div className="cont2 mt-1 mb-4">
        <div className="con1 mx-2">
          <div className="a ml-1">
            <p className="app1" id="log1">
              rentr
            </p>
          </div>
          <div className="b">
            <div className="search-icon">
              <BiSearch />
            </div>
            <input className="search-input" type="text" placeholder="Search Something" />
          </div>
          <div className="c mr-1">
            <button>
              <Link className="nav-link mr-5" to="/login">
                Sign In
              </Link>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Nav;
