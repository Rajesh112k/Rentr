import React from "react";
import './Login.css'

import mail from '/Users/rajeshkumarreddyavula/Desktop/react/apt/src/components/Assets/mail.svg'
import lock from '/Users/rajeshkumarreddyavula/Desktop/react/apt/src/components/Assets/lock.svg'
import Google_G_Logo from '/Users/rajeshkumarreddyavula/Desktop/react/apt/src/components/Assets/Google__G__Logo.png'
import facebook_logo_white from '/Users/rajeshkumarreddyavula/Desktop/react/apt/src/components/Assets/facebook_logo_white.png'
import Apple_logo_white from '/Users/rajeshkumarreddyavula/Desktop/react/apt/src/components/Assets/Apple_logo_white.png'
import x from '/Users/rajeshkumarreddyavula/Desktop/react/apt/src/components/Assets/x.svg'

const Login= () => {
    return (
        <div className = "container">
            <div className = "header">
                <div className="exit">
                    <img src={x} />
                </div>
                <div className = "text"> Login </div>
                <div className="underline"></div>
            </div>
            <div className="welcome"> Welcome to Rentr! </div>
            <div className="inputs">
                <div className="input">
                    <img src={mail} alt="" />
                    <input type="email" placeholder="Email" />
                </div>
                <div className="input">
                    <img src={lock} alt="" />
                    <input type="password" placeholder="Password"/>
                </div>
                <div className="forgot-password"> <span><u>Forgot Password?</u></span></div>
            </div>
            <button className="submit"> LOGIN </button>
            <div className="or"><span>OR</span></div>
            <div className="services">
                <button className="facebook">
                    <img src={facebook_logo_white} alt="" />
                    <div className="facebookText">Continue with Facebook</div>
                </button>
                <button className="google">
                    <img src={Google_G_Logo} alt="" />
                    <div className="googleText">Continue with Google</div>
                </button>
                <button className="apple">
                    <img src={Apple_logo_white} alt="" />
                    <div className="appleText">Continue with Apple</div>
                </button>
            </div>
            <div className="signUp"> <span> Don't have an Account yet? <u>Sign Up</u></span></div>
        </div>
    )
}

export default Login