import React from "react";
import './Signup.css'

import mail from '/Users/ashlynkennedy/Desktop/SE_Team9/SE_TEAM9/frontend/src/Components/Assets/mail.svg'
import lock from '/Users/ashlynkennedy/Desktop/SE_Team9/SE_TEAM9/frontend/src/Components/Assets/lock.svg'
import Google_G_Logo from '/Users/ashlynkennedy/Desktop/SE_Team9/SE_TEAM9/frontend/src/Components/Assets/Google__G__Logo.png'
import facebook_logo_white from '/Users/ashlynkennedy/Desktop/SE_Team9/SE_TEAM9/frontend/src/Components/Assets/facebook_logo_white.png'
import Apple_logo_white from '/Users/ashlynkennedy/Desktop/SE_Team9/SE_TEAM9/frontend/src/Components/Assets/Apple_logo_white.png'
import x from '/Users/ashlynkennedy/Desktop/SE_Team9/SE_TEAM9/frontend/src/Components/Assets/x.svg'
import person from '/Users/ashlynkennedy/Desktop/SE_Team9/SE_TEAM9/frontend/src/Components/Assets/person.svg'
import phone from '/Users/ashlynkennedy/Desktop/SE_Team9/SE_TEAM9/frontend/src/Components/Assets/phone.svg'


const Signup= () => {
    return (
        <div className = "container">
            <div className = "header">
                <div className="exit">
                    <img src={x} />
                </div>
                <div className = "text"> Sign Up </div>
                <div className="underline"></div>
            </div>
            <div className="welcome"> Welcome to Rentr! </div>
            <div className="inputs">
            <div className="input">
                    <img src={person} alt="" />
                    <input type="name" placeholder="Name" />
                </div>
                <div className="input">
                    <img src={mail} alt="" />
                    <input type="email" placeholder="Email" />
                </div>
                <div className="input">
                    <img src={phone} alt="" />
                    <input type="phone" placeholder="Phone Number" />
                </div>
                <div className="input">
                    <img src={lock} alt="" />
                    <input type="password" placeholder="Password"/>
                </div>
            </div>
            <button className="submit"> NEXT </button>
            <div className="or"><span>OR</span></div>
            <div className="services">
                <button className="facebook">
                    <img src={facebook_logo_white} alt="" />
                    <div className="facebookText">Continue with Facebook</div>
                </button>
                <button className="google">
                    <img src={Google_G_Logo} alt="" />
                    <div className="googleText">Continue with Google</div>
                </button>
                <button className="apple">
                    <img src={Apple_logo_white} alt="" />
                    <div className="appleText">Continue with Apple</div>
                </button>
            </div>
            <div className="login"> <span> Already have an Account? <u>Login</u></span></div>
        </div>
    )
}

export default Signup