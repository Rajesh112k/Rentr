import React from "react";
import './PropertyDetails.css'
import { useState } from "react";
import Carousel from 'react-bootstrap/Carousel';

import notBookmarked from '../../Components/Assets/notBookmarked.svg'
import Bookmarked from '../../Components/Assets/Bookmarked.svg'
import fitness from '../../Components/Assets/FitnessCenter.svg'
import pool from '../../Components/Assets/Pool.svg'
import laundry from '../../Components/Assets/Laundry.svg'
import furnished from '../../Components/Assets/Furnished.svg'
import computer from '../../Components/Assets/BusinessCenter.svg'
import wifi from '../../Components/Assets/Wifi.svg'
import pets from '../../Components/Assets/Pets.svg'
import snack from '../../Components/Assets/SnackBar.svg'
import lock from '../../Components/Assets/SecureEntries.svg'
import grill from '../../Components/Assets/Grill.svg'
import email from '../../Components/Assets/mail.svg'
import phone from '../../Components/Assets/phone.svg'
import joe from '../../Components/Assets/joe.svg'
import message from '../../Components/Assets/message.svg'
import verve1 from '../../Components/Assets//Verve/Verve1.png'
import studio from '../../Components/Assets/Verve/studio.png'

const PropertyDetails= () => {
    const [isBookmarked, setIsBookmarked] = useState(false)
    const toggleBookmark = () => {setIsBookmarked(!isBookmarked)}
    const [selectedFloorplan, setSelectedFloorplan] = useState(null);
    const handleFloorplanSelection = (floorplan) => { setSelectedFloorplan(floorplan)}
    const floorplanDetails = {
        Studio: {
          image: studio,
          price: '$1,499',
          size: '343 sqft',
          bed: 'None',
          bath: '1'
        },
        '2 Beds': {
          image: '2bed-image.jpg',
          price: '$1,299',
          size: '779 sqft',
          bed: '2',
          bath: '2'
        },
        '3+ Beds': {
          image: '3plusbed-image.jpg',
          price: '$2,400',
          size: '1200 sq. ft',
          bed: 'None',
          bath: '1'
        }
      }
  
    return (
        <div>
            <div className="Overview-Top">
                <div className="propDetails">
                    <div className="propName"> Verve Bloomington </div>
                    <div className="propAddress"> 1820 N Walnut St, Bloomington, IN 47404 </div>
                </div>
                <button className="leaseApplication"> Apply to Lease </button>
                <button className="Bookmark" onClick = {toggleBookmark}>
                    <img src={isBookmarked ? Bookmarked : notBookmarked} alt="Bookmark Icon" />
                </button>
            </div>
            <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
                <ol class="carousel-indicators">
                    <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
                    <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
                    <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
                </ol>
                <div class="carousel-inner">
                    <div class="carousel-item active">
                    <img class="d-block w-100" src={verve1} alt="First slide" />
                    </div>
                    <div class="carousel-item">
                    <img class="d-block w-100" src={verve1} alt="Second slide" />
                    </div>
                    <div class="carousel-item">
                    <img class="d-block w-100" src={verve1} alt="Third slide" />
                    </div>
                </div>
                <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
                    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                    <span class="sr-only">Previous</span>
                </a>
                <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
                    <span class="carousel-control-next-icon" aria-hidden="true"></span>
                    <span class="sr-only">Next</span>
                </a>
            </div>
            <div className="Overview-Middle">
                <div className="AmenityCol">
                <div className="AmenityLabel">Amenities</div>
                <div className="Amenities">
                    <div className="AmenityCard">
                        <img src={fitness} alt="" />
                        <div className="AmenityName">Fitness Center</div>
                    </div>
                    <div className="AmenityCard">
                        <img src={pool} alt="" />
                        <div className="AmenityName">Pool</div>
                    </div>
                    <div className="AmenityCard">
                        <img src={laundry} alt="" />
                        <div className="AmenityName">In-Unit Laundry</div>
                    </div>
                    <div className="AmenityCard">
                        <img src={furnished} alt="" />
                        <div className="AmenityName">Furnished</div>
                    </div>
                    <div className="AmenityCard">
                        <img src={computer} alt="" />
                        <div className="AmenityName">Business Center</div>
                    </div>
                    <div className="AmenityCard">
                        <img src={wifi} alt="" />
                        <div className="AmenityName">WiFi Included</div>
                    </div>
                    <div className="AmenityCard">
                        <img src={pets} alt="" />
                        <div className="AmenityName">Pet Friendly</div>
                    </div>
                    <div className="AmenityCard">
                        <img src={snack} alt="" />
                        <div className="AmenityName">Snack Bar</div>
                    </div>
                    <div className="AmenityCard">
                        <img src={lock} alt="" />
                        <div className="AmenityName">Secure Entries</div>
                    </div>
                    <div className="AmenityCard">
                        <img src={grill} alt="" />
                        <div className="AmenityName">Grill</div>
                    </div>
                </div>
                </div>
                <div className="ownerCol">
                <div className="OwnerLabel">Property Owner</div>
                <div className="OwnerDetails">
                    <img className="ownerPic" src={joe} alt="" />
                    <div className="ownerContact">
                        <div className="ownerName">Joe Smith</div>
                        <div className="ownerEmail">
                            <img src={email} alt="" />
                            joesmsith@gmail.com
                        </div>
                        <div className="ownerPhone">
                            <img src={phone} alt="" />
                            +1(123)456-7890
                        </div>
                        <button className="messageOwner">
                            <img src={message} alt="" />
                            <div className="messageName">Message Joe</div>
                        </button>
                    </div>
                </div>
                </div>
            </div>
            <div>
            <div className="btn-group btn-group-toggle" data-toggle="buttons">
                {Object.keys(floorplanDetails).map((floorplanOption) => (
                <label
                    key={floorplanOption}
                    className={`btn btn-secondary ${
                    selectedFloorplan === floorplanOption ? 'active' : ''
                    }`}
                    onClick={() => handleFloorplanSelection(floorplanOption)}
                >
                    <input type="radio" name="options" id="option1" autoComplete="off" checked />
                    {floorplanOption}
                </label>
                ))}
            </div>
            <div className="floorplanDetails">
                {selectedFloorplan && (
                    <div>
                    <h2>{selectedFloorplan} Floorplan</h2>
                    <img src={floorplanDetails[selectedFloorplan].image} alt={`${selectedFloorplan} floorplan`} />
                    <p>Price: {floorplanDetails[selectedFloorplan].price}</p>
                    <p>Size: {floorplanDetails[selectedFloorplan].size}</p>
                    </div>
                )}
            </div>
            </div>
        </div>
    )
}

export default PropertyDetails